package com.testing.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Inter1Application {

	public static void main(String[] args) {
		SpringApplication.run(Inter1Application.class, args);
	}
	
	
	

}
